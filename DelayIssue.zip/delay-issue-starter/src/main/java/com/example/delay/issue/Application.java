package com.example.delay.issue;

import io.vertx.core.DeploymentOptions;
import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.core.impl.cpu.CpuCoreSensor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Application {
  public static void main(String[] args) {
    System.setProperty("vertx.logger-delegate-factory-class-name", "io.vertx.core.logging.SLF4JLogDelegateFactory");
    System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", String.valueOf(CpuCoreSensor.availableProcessors() * 2));
    Vertx vertx = Vertx.vertx(new VertxOptions().setPreferNativeTransport(true));
    vertx.deployVerticle(MainVerticle.class, new DeploymentOptions().setWorker(false).setInstances(CpuCoreSensor.availableProcessors() * 2), handler -> {
      if(handler.failed()){
        log.error("Verticle deployment failed", handler.cause());
      }
    });
  }
}
