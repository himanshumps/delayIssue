package com.example.delay.issue;

import io.netty.channel.epoll.Epoll;
import io.netty.handler.ssl.OpenSsl;
import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.http.HttpHeaders;
import io.vertx.core.http.HttpServerOptions;
import io.vertx.core.net.OpenSSLEngineOptions;
import io.vertx.core.net.SelfSignedCertificate;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.LoggerFormat;
import io.vertx.ext.web.handler.LoggerHandler;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;

@Slf4j
public class MainVerticle extends AbstractVerticle {

  private final List<String> responseArray = new ArrayList();
  private final Random random = new Random();
  @Override
  public void start(Promise<Void> startPromise) throws Exception {
    // Initializing an arraylist with string of random size between 10 KB to 20 KB
    for (int i = 0; i < 1000; i++) {
      responseArray.add("a".repeat(random.nextInt(10 * 1024, 20*1024)));
    }

    SelfSignedCertificate certificate = SelfSignedCertificate.create();
    HttpServerOptions httpServerOptions = new HttpServerOptions()
      .setSsl(true)
      .setSslEngineOptions(new OpenSSLEngineOptions().setSessionCacheEnabled(false))
      .setKeyCertOptions(certificate.keyCertOptions());

    Router router = Router.router(vertx);
    router.get().handler(LoggerHandler.create(LoggerFormat.TINY));
    router.get("/test/:identifier").handler(this::getTestIdentifier);

    vertx.createHttpServer(httpServerOptions).requestHandler(router).listen(8443, handler -> {
      if(handler.succeeded()) {
        log.info("Server started on port 8443. epoll: {}, openssl: {}", Epoll.isAvailable(), OpenSsl.isAvailable());
        startPromise.complete();
      } else {
        log.error("Server failed to start on port 8443", handler.cause());
        startPromise.fail(handler.cause());
      }
    });
  }

  private void getTestIdentifier(RoutingContext routingContext) {
    routingContext.response()
      .setStatusCode(200)
      .putHeader("identifier", routingContext.pathParam("identifier"))
      .putHeader(HttpHeaders.CONTENT_TYPE, "text/plain")
      .end(responseArray.get(random.nextInt(responseArray.size())));
  }
}
