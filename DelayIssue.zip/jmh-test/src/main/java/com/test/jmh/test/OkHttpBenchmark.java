/*
 * Copyright (c) 2005, 2014, Oracle and/or its affiliates. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Oracle designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Oracle in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
 * or visit www.oracle.com if you need additional information or have any
 * questions.
 */

package com.test.jmh.test;

import lombok.extern.slf4j.Slf4j;
import okhttp3.*;
import org.openjdk.jmh.annotations.*;
import org.openjdk.jmh.infra.BenchmarkParams;
import org.openjdk.jmh.infra.Blackhole;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

@State(Scope.Benchmark)
// State objects naturally encapsulate the state on which benchmark is working on. The Scope of state object defines to which extent it is shared among the worker threads.
@BenchmarkMode(Mode.SampleTime) // Average time taken per operation(1 REST API request & response).
@OutputTimeUnit(TimeUnit.MILLISECONDS) // Default time unit to report the results in
@Warmup(iterations = 1, time = 5, timeUnit = TimeUnit.MINUTES) // Default 1 iteration of 1 minutes for warmup
@Measurement(iterations = 1, time = 30, timeUnit = TimeUnit.MINUTES) // Default 1 iteration of 10 minutes
@Timeout(time = 40, timeUnit = TimeUnit.MINUTES) // Default 15 minutes timeout
@Fork(1) // Default to one fork from 5
@Slf4j
public class OkHttpBenchmark {

  TrustManager[] trustAllCerts = new TrustManager[]{
      new X509TrustManager() {
        @Override
        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
        }

        @Override
        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
        }

        @Override
        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
          return new java.security.cert.X509Certificate[]{};
        }
      }
  };

  private OkHttpClient okHttpClient;
  private int threshold;

  @Setup(Level.Iteration)
  public void iterationSetup(BenchmarkParams benchmarkParams) {
    // TODO: Change the threshold as you see fit. For this test the LoggerHandler reports 0-1 ms and 20 is a good threshold
    threshold = Integer.parseInt(System.getProperty("threshold", "20"));
  }

  @Setup
  public void setup(BenchmarkParams benchmarkParams) throws IOException, KeyManagementException, NoSuchAlgorithmException {
    SSLContext sslContext = SSLContext.getInstance("SSL");
    sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
    this.okHttpClient = new OkHttpClient.Builder()
        .sslSocketFactory(sslContext.getSocketFactory(), (X509TrustManager) trustAllCerts[0])
        .hostnameVerifier((hostname, session) -> true)
        .eventListenerFactory(PrintingEventListener.FACTORY)
        .connectionPool(new ConnectionPool(benchmarkParams.getThreads() + 2, 5, TimeUnit.MINUTES)) // Each thread uses a connection from the pool
        .protocols(Arrays.asList(Protocol.HTTP_1_1))
        .build();
  }

  @Benchmark
  @Threads(20) // Default 20 threads
  public void testMethod(Blackhole blackhole) throws IOException {
    final String identifier = UUID.randomUUID().toString();
    Request request = new Request.Builder()
        .addHeader("identifier", identifier)
        .addHeader("accept", "application/json;version=3.0.0")
        .get()
        .url(new URL("https://localhost:8443/test/" + identifier)) // TODO: Change localhost to machine name if running on two different machines
        .build();

    try (Response response = okHttpClient.newCall(request).execute()) {
      long timeTaken = System.currentTimeMillis() - response.sentRequestAtMillis();
      if (response.code() != 200 || timeTaken > threshold) {
        System.out.println("Check logs for identifier " + identifier + " with response code " + response.code() + " and time taken " + timeTaken);
      }
      blackhole.consume(response.body());
    } catch (Exception e) {
      e.printStackTrace();
      throw new RuntimeException(e);
    }
  }

  @TearDown
  public void tearDownTrial() {
    okHttpClient.dispatcher().executorService().shutdown();
    okHttpClient.connectionPool().evictAll();
  }

  private static final class PrintingEventListener extends EventListener {
    private static final Factory FACTORY = new Factory() {
      final AtomicLong nextCallId = new AtomicLong(1L);

      @Override
      public EventListener create(Call call) {
        long callId = nextCallId.getAndIncrement();
        //System.out.printf("%04d %s%n", callId, call.request().url(), call.request().header("identifier"));
        return new PrintingEventListener(callId, System.nanoTime());
      }
    };

    final long callId;
    final long callStartNanos;

    PrintingEventListener(long callId, long callStartNanos) {
      this.callId = callId;
      this.callStartNanos = callStartNanos;
    }

    private void printEvent(String name, String identifier) {
      long elapsedNanos = System.nanoTime() - callStartNanos;
      log.info(String.format("%04d %.3f %s %s%n", callId, elapsedNanos / 1000000000d, name, identifier));
    }

    @Override
    public void proxySelectStart(Call call, HttpUrl url) {
      printEvent("proxySelectStart", call.request().header("identifier"));
    }

    @Override
    public void proxySelectEnd(Call call, HttpUrl url, List<Proxy> proxies) {
      printEvent("proxySelectEnd", call.request().header("identifier"));
    }

    @Override
    public void callStart(Call call) {
      printEvent("callStart", call.request().header("identifier"));
    }

    @Override
    public void dnsStart(Call call, String domainName) {
      printEvent("dnsStart", call.request().header("identifier"));
    }

    @Override
    public void dnsEnd(Call call, String domainName, List<InetAddress> inetAddressList) {
      printEvent("dnsEnd", call.request().header("identifier"));
    }

    @Override
    public void connectStart(
        Call call, InetSocketAddress inetSocketAddress, Proxy proxy) {
      printEvent("connectStart", call.request().header("identifier"));
    }

    @Override
    public void secureConnectStart(Call call) {
      printEvent("secureConnectStart", call.request().header("identifier"));
    }

    @Override
    public void secureConnectEnd(Call call, Handshake handshake) {
      printEvent("secureConnectEnd", call.request().header("identifier"));
    }

    @Override
    public void connectEnd(
        Call call, InetSocketAddress inetSocketAddress, Proxy proxy, Protocol protocol) {
      printEvent("connectEnd", call.request().header("identifier"));
    }

    @Override
    public void connectFailed(Call call, InetSocketAddress inetSocketAddress, Proxy proxy,
                              Protocol protocol, IOException ioe) {
      printEvent("connectFailed", call.request().header("identifier"));
    }

    @Override
    public void connectionAcquired(Call call, Connection connection) {
      printEvent("connectionAcquired", call.request().header("identifier"));
    }

    @Override
    public void connectionReleased(Call call, Connection connection) {
      printEvent("connectionReleased", call.request().header("identifier"));
    }

    @Override
    public void requestHeadersStart(Call call) {
      printEvent("requestHeadersStart", call.request().header("identifier"));
    }

    @Override
    public void requestHeadersEnd(Call call, Request request) {
      printEvent("requestHeadersEnd", call.request().header("identifier"));
    }

    @Override
    public void requestBodyStart(Call call) {
      printEvent("requestBodyStart", call.request().header("identifier"));
    }

    @Override
    public void requestBodyEnd(Call call, long byteCount) {
      printEvent("requestBodyEnd", call.request().header("identifier"));
    }

    @Override
    public void requestFailed(Call call, IOException ioe) {
      printEvent("requestFailed", call.request().header("identifier"));
    }

    @Override
    public void responseHeadersStart(Call call) {
      printEvent("responseHeadersStart", call.request().header("identifier"));
    }

    @Override
    public void responseHeadersEnd(Call call, Response response) {
      printEvent("responseHeadersEnd", call.request().header("identifier"));
    }

    @Override
    public void responseBodyStart(Call call) {
      printEvent("responseBodyStart", call.request().header("identifier"));
    }

    @Override
    public void responseBodyEnd(Call call, long byteCount) {
      printEvent("responseBodyEnd", call.request().header("identifier"));
    }

    @Override
    public void responseFailed(Call call, IOException ioe) {
      printEvent("responseFailed", call.request().header("identifier"));
    }

    @Override
    public void callEnd(Call call) {
      printEvent("callEnd", call.request().header("identifier"));
    }

    @Override
    public void callFailed(Call call, IOException ioe) {
      printEvent("callFailed", call.request().header("identifier"));
    }

    @Override
    public void canceled(Call call) {
      printEvent("canceled", call.request().header("identifier"));
    }
  }
}
